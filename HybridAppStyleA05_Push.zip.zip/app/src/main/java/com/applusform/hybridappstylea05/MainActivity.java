package com.applusform.hybridappstylea05;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;

import com.applusform.pushwoosh.PushwooshObjectComponent;

import org.mospi.moml.framework.pub.core.MOMLActivity;
import org.mospi.moml.webkit.pub.core.MOMLWebKit;

public class MainActivity extends MOMLActivity {
    
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // for Pushwoosh 1/2 : applicationCode 와 projectNumber 를 알맞게 수정합니다.   
        {
	        String applicationCode = "45E1B-3151D"; // http://pushwoosh.com 에 등록되어 있는 앱의 Application code
	        String projectNumber = "97931105397"; // https://code.google.com/apis/console 의 Overmenu 메뉴의 Dashboard에 표시되는 Project Number
	        PushwooshObjectComponent.setAppInfo(applicationCode, projectNumber);
	        
	        getMomlView().registerObjectComponent("com.applusform.pushwoosh.PushwooshObjectComponent", "pushwoosh", "object", this);
        }
        
        MOMLWebKit.init(getMomlView());
        
        this.loadApplication("applicationInfo.xml");
    }
    
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
        	getMomlView().getRoot().runCommand("function.root.onMenuKey", null);
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }
    
    protected void onDestroy() {
    	super.onDestroy();
    	System.exit(0);
    }
    
    // for Pushwoosh 2/2 : Pushwoosh Object의 onResume, onPause, onNewIntent 함수를 호출합니다.    
	@Override
	public void onResume() {
		super.onResume();
		PushwooshObjectComponent object = PushwooshObjectComponent.getObject(getMomlView());
		object.onResume();
	}

	@Override
	public void onPause() {
		super.onPause();
		PushwooshObjectComponent object = PushwooshObjectComponent.getObject(getMomlView());
		object.onPause();
	}

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		PushwooshObjectComponent object = PushwooshObjectComponent.getObject(getMomlView());
		object.onNewIntent(intent);
	}
}
