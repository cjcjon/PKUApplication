package com.applusform.pushwoosh;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;
import org.mospi.moml.framework.pub.core.IMOMLBaseActivityProxy;
import org.mospi.moml.framework.pub.core.MOMLObject;
import org.mospi.moml.framework.pub.core.MOMLView;
import org.mospi.moml.framework.pub.object.MOMLComponent;
import org.mospi.moml.framework.pub.objectapi.ObjectApiInfo;

import com.arellomobile.android.push.BasePushMessageReceiver;
import com.arellomobile.android.push.PushManager;
import com.arellomobile.android.push.utils.RegisterBroadcastReceiver;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

public class PushwooshObjectComponent extends DefaultObjectComponent {
	private static String APP_ID;
	private static String SENDER_ID;
	private static HashMap<MOMLView, PushwooshObjectComponent> objectMap = new HashMap<MOMLView, PushwooshObjectComponent>();
	PushManager pushManager;

	public static void setAppInfo(String applicationCode, String projectNumber) {
		APP_ID = applicationCode;
		SENDER_ID = projectNumber;
	}
	
	private boolean isTestNumber() {
		return SENDER_ID.equals("1234567890123");
	}

	public static PushwooshObjectComponent getObject(MOMLView momlView) {
		return objectMap.get(momlView);
	}

	@Override
	public void initBase(final Context context, MOMLComponent base, Object userObj, MOMLObject obj) {
		super.initBase(context, base, userObj, obj);
		objectMap.put(getMomlView(), this);
		pushManager = new PushManager(getActivity(), APP_ID, SENDER_ID);
		if (!isTestNumber()) {
			registerReceivers();
			checkMessage(getActivity().getIntent());
		}
	}

	@Override
	public ObjectApiInfo getObjectApiInfo() {
		ObjectApiInfo apiInfo = ObjectApiInfo.createObjectApiInfo("pushwoosh", "1.0.0", "1.0.0", "", getBase());
		apiInfo.registerMethod("register", null, 1, "1.0.0", "1.0.0", "");
		apiInfo.registerMethod("unregister", null, 0, "1.0.0", "1.0.0", "");
		return apiInfo;
	}

	public MOMLView getMomlView() {
		if (userObj instanceof IMOMLBaseActivityProxy)
			return ((IMOMLBaseActivityProxy) userObj).getMomlView();
		return null;
	}

	public Activity getActivity() {
		if (userObj instanceof Activity)
			return (Activity) userObj;
		return null;
	}

	@Override
	public String callFunction(String name, Object... args) {
		if (name.equals("register") && args.length == 1) {
			return register(args[0].toString());
		} else if (name.equals("unregister")) {
			return unregister();
		}

		return null;
		// return super.callFunction(name, args);
	}

	private String onPushMsgfunction;

	String register(String functionName) {
		if (!isTestNumber()) {
			onPushMsgfunction = functionName;
			// Register receivers for push notifications
			registerReceivers();
	
			// Create and start push manager
			// pushManager.unregister();
			pushManager.onStartup(getActivity());
	
			checkMessage(getActivity().getIntent());
		}
		return "";
	}

	String unregister() {
		if (!isTestNumber()) {
			pushManager.unregister();
		}

		return "";
	}

	String pushMessage = "";

	private void onPushMessage(String msg) {
		try {
			JSONObject jsonMsg = new JSONObject(msg);
			pushMessage = jsonMsg.getString("title");
		} catch (JSONException e) {
			// No custom JSON. Pass this exception
		}

		new Handler().postDelayed(new Runnable() {
			@Override
			public void run() {
				if (onPushMsgfunction != null && onPushMsgfunction.length() > 0)
					getMomlView().getRootContainer().runCommand("function." + onPushMsgfunction + "('" + pushMessage + "')", null);
			}
		}, 1000);
		// showMessage(msg);
	}

	// Registration receiver
	BroadcastReceiver mBroadcastReceiver = new RegisterBroadcastReceiver() {
		@Override
		public void onRegisterActionReceive(Context context, Intent intent) {
			checkMessage(intent);
		}
	};

	// Push message receiver
	private BroadcastReceiver mReceiver = new BasePushMessageReceiver() {
		@Override
		protected void onMessageReceive(Intent intent) {
			// JSON_DATA_KEY contains JSON payload of push notification.
			// showMessage("push message is " + intent.getExtras().getString(JSON_DATA_KEY));
			onPushMessage(intent.getExtras().getString(JSON_DATA_KEY));
		}
	};

	// Registration of the receivers
	public void registerReceivers() {
		if (!isTestNumber()) {
			IntentFilter intentFilter = new IntentFilter(getActivity().getPackageName() + ".action.PUSH_MESSAGE_RECEIVE");

			getActivity().registerReceiver(mReceiver, intentFilter);

			getActivity().registerReceiver(mBroadcastReceiver, new IntentFilter(getActivity().getPackageName() + "." + PushManager.REGISTER_BROAD_CAST_ACTION));
		}
	}

	public void unregisterReceivers() {
		if (!isTestNumber()) {
			// Unregister receivers on pause
			try {
				getActivity().unregisterReceiver(mReceiver);
			} catch (Exception e) {
				// pass.
			}

			try {
				getActivity().unregisterReceiver(mBroadcastReceiver);
			} catch (Exception e) {
				// pass through
			}
		}
	}

	public void onResume() {
		// Re-register receivers on resume
		registerReceivers();
	}

	public void onPause() {
		// Unregister receivers on pause
		unregisterReceivers();
	}

	public void onNewIntent(Intent intent) {
		getActivity().setIntent(intent);

		checkMessage(intent);

		getActivity().setIntent(new Intent());
	}

	private void checkMessage(Intent intent) {
		if (null != intent) {
			if (intent.hasExtra(PushManager.PUSH_RECEIVE_EVENT)) {
				String msg = intent.getExtras().getString(PushManager.PUSH_RECEIVE_EVENT);
				onPushMessage(msg);
				showMessage("push message is " + msg);
			} else if (intent.hasExtra(PushManager.REGISTER_EVENT)) {
				showMessage("register");
			} else if (intent.hasExtra(PushManager.UNREGISTER_EVENT)) {
				showMessage("unregister");
			} else if (intent.hasExtra(PushManager.REGISTER_ERROR_EVENT)) {
				showError("push register error");
			} else if (intent.hasExtra(PushManager.UNREGISTER_ERROR_EVENT)) {
				showError("push unregister error");
			}

			resetIntentValues();
		}
	}

	/**
	 * Will check main Activity intent and if it contains any PushWoosh data, will clear it
	 */
	private void resetIntentValues() {
		Intent mainAppIntent = getActivity().getIntent();

		if (mainAppIntent.hasExtra(PushManager.PUSH_RECEIVE_EVENT)) {
			mainAppIntent.removeExtra(PushManager.PUSH_RECEIVE_EVENT);
		} else if (mainAppIntent.hasExtra(PushManager.REGISTER_EVENT)) {
			mainAppIntent.removeExtra(PushManager.REGISTER_EVENT);
		} else if (mainAppIntent.hasExtra(PushManager.UNREGISTER_EVENT)) {
			mainAppIntent.removeExtra(PushManager.UNREGISTER_EVENT);
		} else if (mainAppIntent.hasExtra(PushManager.REGISTER_ERROR_EVENT)) {
			mainAppIntent.removeExtra(PushManager.REGISTER_ERROR_EVENT);
		} else if (mainAppIntent.hasExtra(PushManager.UNREGISTER_ERROR_EVENT)) {
			mainAppIntent.removeExtra(PushManager.UNREGISTER_ERROR_EVENT);
		}

		getActivity().setIntent(mainAppIntent);
	}

	private void showMessage(String message) {
		Log.i("Pushwoosh", message);
	}
	
	private void showError(String message) {
		Log.e("Pushwoosh", message);
		Toast.makeText(getActivity(), message, Toast.LENGTH_LONG).show();
	}

}
