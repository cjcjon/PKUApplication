package com.applusform.pushwoosh;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Locale;

import org.mospi.moml.framework.pub.core.MOMLObject;
import org.mospi.moml.framework.pub.object.MOMLComponent;
import org.mospi.moml.framework.pub.objectapi.ObjectApiInfo;
import org.mospi.moml.framework.pub.util.ComponentReflect;

import android.content.Context;

public class DefaultObjectComponent implements MOMLComponent {

	protected Context context;
	protected String name;
	protected String baseName;
	protected MOMLComponent baseComponent;
	protected MOMLObject obj;
	protected Object userObj;
	protected ObjectApiInfo objectApiInfo;
	private ArrayList<CallFunctionInfo> functionArray;

	class CallFunctionInfo {
		public String name;
		public Object[] parameters;
	}

	@Override
	public void initBase(final Context context, MOMLComponent base, Object userObj, MOMLObject obj) {
		this.context = context;
		this.baseComponent = base;
		this.obj = obj;
		this.userObj = userObj;

	}

	@Override
	public String callFunction(String name, Object... args) {
		String result = null;
		if (functionArray == null) {
			functionArray = new ArrayList<CallFunctionInfo>();
		}

		CallFunctionInfo info = new CallFunctionInfo();
		info.name = name;
		info.parameters = args;
		functionArray.add(info);

		Object[] methodInfo = ComponentReflect.findComponentMethod(this, name, args);
		if (methodInfo != null) {
			Object ret = ComponentReflect.invokeMethod(methodInfo[0], name, args, (Method) methodInfo[1]);
			if (ret != null)
				result = ret.toString();
			else
				result = null;
		} else {
			result = baseComponent.callFunction(name, args);
		}

		functionArray.remove(functionArray.size() - 1);
		return result;
	}

	@Override
	public Context getContext() {
		return this.context;
	}

	public ObjectApiInfo createObjectApiInfo() {
		return null;
	}

	@Override
	public ObjectApiInfo getObjectApiInfo() {
		if (objectApiInfo == null)
			objectApiInfo = createObjectApiInfo();
		
		if (objectApiInfo != null)
			return objectApiInfo;
		
		return baseComponent.getObjectApiInfo();
	}

	@Override
	public MOMLComponent getBase() {
		return baseComponent;
	}

	public String baseCallFunction() {
		if (functionArray.size() <= 0)
			return null;

		CallFunctionInfo info = functionArray.get(functionArray.size() - 1);
		return baseComponent.callFunction(info.name, info.parameters);
	}

	protected String convertSetAttrName(String attrName) {
		StringBuilder sb = new StringBuilder();
		sb.append("set");
		sb.append(attrName.substring(0, 1).toUpperCase(Locale.ENGLISH));
		if (attrName.length() > 1)
			sb.append(attrName.substring(1, attrName.length()));
		return sb.toString();
	}
}
